import { AddCustomerComponent } from './add-customer/add-customer.component';
import { DetailsComponent } from './details/details.component';
import { HomeComponent } from './home/home.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { NewAccountComponent } from './new-account/new-account.component';
import { ForgotPassComponent } from './forgot-pass/forgot-pass.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path:'',component:HomeComponent},
  { path:'forgot-pass',component:ForgotPassComponent},
  { path:'new-account',component:NewAccountComponent},
  { path:'sign-in',component:SignInComponent},
  { path:'details',component:DetailsComponent},
  { path:'add-customer',component:AddCustomerComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { 

}
