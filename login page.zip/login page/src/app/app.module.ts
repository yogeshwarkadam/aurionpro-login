import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ForgotPassComponent } from './forgot-pass/forgot-pass.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { NewAccountComponent } from './new-account/new-account.component';
import { DetailsComponent } from './details/details.component';
import { AddCustomerComponent } from './add-customer/add-customer.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ForgotPassComponent,
    SignInComponent,
    NewAccountComponent,
    DetailsComponent,
    AddCustomerComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
